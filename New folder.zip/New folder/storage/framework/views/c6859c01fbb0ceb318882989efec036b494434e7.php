<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>

        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title><?php echo e(isset($title) ? $title : ''); ?></title>

         <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <meta name="description" content="<?php echo e(isset($description) ? $description :''); ?>">
        <meta name="keywords" content="<?php echo e(isset($keywords) ? $keywords :''); ?>">
        <meta name="robots" content="index,follow">
        <meta name="author" content="<?php echo e(isset($author) ? $author :''); ?>" />
        <link rel="canonical" href="<?php echo e(isset($og_url) ? $og_url :''); ?>" />
        <meta property="og:locale" content="en_US" />
        <meta property="og:type" content="<?php echo e(isset($og_type) ? $og_type :''); ?>" />
        <meta property="og:url" content="<?php echo e(isset($og_url) ? $og_url :''); ?>" />
        <meta property="og:title" content="<?php echo e(isset($title) ? $title : ''); ?>" />
        <meta property="og:description" content="Anira Chemicals is a young manufacturer of wide range of construction chemicals and allied products.  At ACPL, we aim at delivering high quality goods and providing impeccable services. We are a technologically driven company and excel in providing customized/  tailor made solutions for our customers to  suit their specific requirements." />
        <meta property="og:site_name" content="Anira Chemicals" />
        <meta property="og:image" content="http://anirachemicals.com/public/assets/img/logo-name.png" />

        <!-- Favicons -->
        <link href="<?php echo e($publicurl); ?>assets/img/favicon.png" rel="icon">
        <link href="<?php echo e($publicurl); ?>assets/img/apple-touch-icon.png" rel="apple-touch-icon">

        <!-- Google Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Raleway:300,400,500,700,800|Montserrat:300,400,700" rel="stylesheet">

        <!-- Vendor CSS Files -->
        <link href="<?php echo e(asset($publicurl.'assets/vendor/aos/aos.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset($publicurl.'assets/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset($publicurl.'assets/vendor/bootstrap-icons/bootstrap-icons.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset($publicurl.'assets/vendor/boxicons/css/boxicons.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset($publicurl.'assets/vendor/glightbox/css/glightbox.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset($publicurl.'assets/vendor/swiper/swiper-bundle.min.css')); ?>" rel="stylesheet">

        <!-- Template Main CSS File -->
        <link href="<?php echo e(asset($publicurl.'assets/css/style.css')); ?>" rel="stylesheet">

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

    </head>
    <body>

        

        <?php if (isset($component)) { $__componentOriginal11b64bccd088ce75d1413ed95ac1bc19c074dba6 = $component; } ?>
<?php $component = App\View\Components\Heade::resolve(['publicurl' => ''.e($publicurl).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('heade'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Heade::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal11b64bccd088ce75d1413ed95ac1bc19c074dba6)): ?>
<?php $component = $__componentOriginal11b64bccd088ce75d1413ed95ac1bc19c074dba6; ?>
<?php unset($__componentOriginal11b64bccd088ce75d1413ed95ac1bc19c074dba6); ?>
<?php endif; ?>
        
        
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.hero_section','data' => ['publicurl' => ''.e($publicurl).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('hero_section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['publicurl' => ''.e($publicurl).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        


        <main id="main">
        <?php echo $__env->yieldContent('content'); ?>
        </main>

        <?php if (isset($component)) { $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf = $component; } ?>
<?php $component = App\View\Components\Footer::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Footer::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf)): ?>
<?php $component = $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf; ?>
<?php unset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf); ?>
<?php endif; ?>

        <!-- Vendor JS Files -->
    <script src="<?php echo e(asset($publicurl.'assets/vendor/aos/aos.js')); ?>"></script>
    <script src="<?php echo e(asset($publicurl.'assets/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset($publicurl.'assets/vendor/glightbox/js/glightbox.min.js')); ?>"></script>
    <script src="<?php echo e(asset($publicurl.'assets/vendor/isotope-layout/isotope.pkgd.min.js')); ?>"></script>
    <script src="<?php echo e(asset($publicurl.'assets/vendor/php-email-form/validate.js')); ?>"></script>
    <script src="<?php echo e(asset($publicurl.'assets/vendor/swiper/swiper-bundle.min.js')); ?>"></script>

    <!-- Template Main JS File -->
    <script src="<?php echo e(asset($publicurl.'assets/js/main.js')); ?>"></script>

    </body>
</html>
<?php /**PATH C:\xampp\htdocs\Laravel Project\anirachemicals\resources\views/layouts/base.blade.php ENDPATH**/ ?>