<div class="card py-2">
    <ul class="nav nav-tabs" role="tablist">
        <li class="nav-item">
            <a class="nav-link <?php echo e($activeTab == 'list' ? 'active' : ''); ?> " id="add-tab"  href="<?php echo e(route('vendor')); ?>"  aria-controls="list" aria-selected="true">List</a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo e($activeTab == 'add' ? 'active' : ''); ?>" id="list-tab"  href="<?php echo e(route('vendor')); ?>"  aria-controls="add" aria-selected="false">Add New</a>
        </li>
        <?php if($activeTab == 'edit'): ?>
        <li class="nav-item">
            <a class="nav-link <?php echo e($activeTab == 'edit' ? 'active' : ''); ?>" id="edit" href="#edit"  aria-controls="edit" aria-selected="false">Edit</a>
        </li>
        <?php endif; ?>
    </ul>
</div>
<?php /**PATH C:\xampp\htdocs\Laravel Project\anirachemicals\resources\views/admin/components/header-nav/vendor-nav.blade.php ENDPATH**/ ?>