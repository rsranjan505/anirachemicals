<footer class="footer">
    <div class="d-sm-flex justify-content-center justify-content-sm-between">
        <span class="text-muted text-center text-sm-left d-block d-sm-inline-block"><a href="https://www.anirachemicals.com/" target="_blank">Anira Chemicals Private Limited</a>. All rights reserved.</span>
   </div>
</footer>
