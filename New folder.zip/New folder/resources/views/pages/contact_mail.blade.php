
 <h3>Contact data.</h3>

 <table border="1">

    <tbody>
        <tr>
            <td>Name:   </td>
            <td>{{$name}}   </td>
        </tr>
        <tr>
            <td>Email:   </td>
            <td>{{$email}}   </td>
        </tr>
        <tr>
            <td>Subject:   </td>
            <td>{{$subject}}   </td>
        </tr>
        <tr>
            <td>Message:   </td>
            <td>{{$msg}}   </td>
        </tr>
    </tbody>
</table>
