<h3>Enquiry data.</h3>
<table border="1">
    <tbody>
        <tr>
            <td>First Name:   </td>
            <td>{{$first_name }}   </td>
        </tr>
        <tr>
            <td>Last Name:   </td>
            <td>{{$last_name}}   </td>
        </tr>
        <tr>
            <td>Email:   </td>
            <td>{{$email}}   </td>
        </tr>
        <tr>
            <td>Mobile:   </td>
            <td>{{$mobile}}   </td>
        </tr>
        <tr>
            <td>State:   </td>
            <td>{{ $state}}   </td>
        </tr>
        <tr>
            <td>District:   </td>
            <td>{{$district}}   </td>
        </tr>
        <tr>
            <td>Meassge:   </td>
            <td>{{$msg}}   </td>
        </tr>
    </tbody>
</table>
